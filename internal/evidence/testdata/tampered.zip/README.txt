Synthetic compliance bundle for verifier tests. It describes no real organization.
