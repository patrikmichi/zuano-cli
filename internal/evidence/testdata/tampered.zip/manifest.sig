{
  "purpose": "compliance-manifest",
  "kid": "fixture-evidence",
  "alg": "ed25519",
  "signature": "vUU3pMPVk3jGsGObGyJw4vIHbJInfBA45VLdOa9TvLAo7ketk7qY/SUyEdsKMImPTK03wBaZYkenvprxftdPAg=="
}
